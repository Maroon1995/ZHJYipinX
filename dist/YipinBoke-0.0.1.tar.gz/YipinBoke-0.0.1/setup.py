from setuptools import setup, find_packages

setup(
    name='YipinBoke',
    version='0.0.1',
    description='字符串唯一化',
    packages=find_packages('.'),
    package_dir={'': '.'},
    package_data={"ZHJYipinX": ["resource/configuration.yaml"]},
    python_requires=">=3.8",
)
